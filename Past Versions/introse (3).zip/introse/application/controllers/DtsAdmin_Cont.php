<?php 

Class DtsAdmin_Cont extends CI_Controller{


	public function index()
	{
		$this->home();
	}
	public function home(){
		$this->load->view('include/DtsHead');
		$this->load->view('include/Nav_Admin');
		$this->load->view('DtsAdmin');	
	}



}
?>