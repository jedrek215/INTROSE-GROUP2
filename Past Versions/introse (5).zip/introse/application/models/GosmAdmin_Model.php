<?php 
Class GosmAdmin_Model extends CI_Model
{
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
 
    
   function getGosm_org($orgname,$limit, $start)
   {
     $code = 'SELECT * 
              from gosm, targetdate, org
              where OrgName like '.'"%'.$orgname.'%"'.' and OrgID = Gosm_OrgID 
              and gosmID = date_gosmID';

      if($limit != 0 ){
         $code =  $code . ' limit ' . $start . ', ' . $limit;
     }


      $query = $this->db->query($code);
      if($query->num_rows()>0){

        return $query->result();
      }else {
        return NULL;
      }

    }

    function getGosm($limit, $start)
   {
     $code = 'SELECT * 
              from gosm, targetdate, org
              where OrgID = Gosm_OrgID and gosmID = date_gosmID';
      if($limit != 0 ){
         $code =  $code . ' limit ' . $start . ', ' . $limit;
     }


      $query = $this->db->query($code);
      if($query->num_rows()>0){

        return $query->result();
      }else {
        return NULL;
      }

    }

    function getOrgs()
   {
     $code = 'SELECT * FROM cso.org;';

      $query = $this->db->query($code);
      if($query->num_rows()>0){

        return $query->result();
      }else {
        return NULL;
      }

    }

        function getGosmTitlefilter($orgname, $text, $limit, $start){
       $code = 'SELECT *
              from gosm, targetdate, org
              where OrgName like '.'"%'.$orgname.'%"'.'  and OrgID = Gosm_OrgID and gosmID = date_gosmID and Title Like '.'"%'.$text.'%"'.'';

        if($limit != 0 ){
         $code =  $code . ' limit ' . $start . ', ' . $limit;
     }
             
      $query = $this->db->query($code);
      if($query->num_rows()>0){

        return $query->result();
      }else {
        return NULL;
      }
    }

   
   function __destruct() {
        $this->db->close();
    }

}

?>