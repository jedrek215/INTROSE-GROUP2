    <!DOCTYPE html>

<html lang="en">
<body>
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="col-lg-12">
                <h1 class="page-header">
                    GOSM <small> Goals|Objectives|Strategies|Measures </small>
                </h1>
            </div>
            <div class="col-lg-12">
                <div class="panel panel-default text-center">
                   
                    <div class="panel-body bg-2">
                        <table width="100%" class="table table-striped table-bordered table-hover" id="gosm">
                            <thead>
                                <th>Gosm id</th>
                                <th>Activity Title</th>
                                <th>More Info</th>
                            </thead>
                            <tbody>
                                <?php displayAsTable( $gosm) ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                    <div class="row">
                     <div class="col-md-12 text-center">
                        <?php echo $pagination; ?>
                     </div>
                    </div>
               </div>
        </div>
    </div>

   

    <font id="hidden"></font>

    <?php
        $activities =0;

        

        function displayAsTable( $activity){
            $count = 1;
            $activities = $activity;
            if($activities){
             foreach ($activities as $row){
               
              echo '<tr>';
                
                echo '<td>' . $row->gosmID .  '</td>';
                echo '<td id = "title" class = "$count">' . $row->Title . '</td>';
                echo '<td>' . '<button type="button" class= "btn btn-primary" aria-label ="center" data-toggle="modal" data-target = "#modal-'.$count.'">
                    <span class ="glyphicon glyphicon-info-sign" aria-hidden = "true"></span>
                     </button>' . '</td>';
              echo '<tr>';
              makeModal($row,$count);
                $count++;          
            }
            }
        }

        function makeModal($data, $count){
            echo '<div class ="container">';
            echo '<div class = "modal fade" id= "modal-'.$count.'">';
            echo    '<div class = "modal-dialog">';
            echo    '<div class = "modal-content">';
            echo        '<div class = "modal-header">';
            echo            '<button type ="button" class = "close"data-dismiss= "modal">&times;</button>';
            echo            '<h3 class="modal-title" align="left"><b>' . $data->Title .
                            '</b><small>&nbsp;Details</small></h3>';  
            echo        '</div>';
            echo        '<div class = "modal-body" style= "text-align :left">';
            echo                '<label>Goals: </label><div> ' . $data->Goals . '</div><br>';
            echo                '<label>Objectives:</label> <div>' . $data->Objectives . '</div><br>';
            echo                '<label>Brief Description:</label> ' . $data->BriefDesc . '<br>';
            echo                '<label>Measures:</label> ' . $data->Measures . '<br>';
            echo                '<label>Target Date :</label> ';
                if($data->G_EndDate == NULL && $data->G_OneDate != NULL){
                    echo $data->G_OneDate.  '<br>';
                }
                else if($data->G_OneDate == NULL && $data->G_EndDate == NULL)
                    echo  $data->Particulars . '<br>';
                else{
                    echo  $data->G_OneDate . ' — ' . $data->G_EndDate . '<br>';
                }
            echo                '<label>Officer-in-Charge:</label> ' . $data->inCharge . '<br>';
            echo                '<label>Activity Nature:</label> ' . $data->GNature . '<br>';
            echo                '<label>Activity Type:</label> ' . $data->GType . '<br>';
            echo                '<label>Related to Nature Organization:</label> '
                                 . $data->Related . '<br>';
            echo                '<label>Budget:</label> ' . $data->Budget . '<br>';
            if ($data->Venue != NULL){
            echo                '<label>Venue:</label> ' . $data->Venue . '<br>';
            }
            echo        '<div class = "modal-footer">';
            echo            '<a href="" class="btn btn-default" data-dismiss="modal">Close</a>';                        
            echo        '</div>';
            echo    '</div>';
            echo   '</div>';
            echo    '</div>';
            echo '</div>';

        }
    ?>


</body>

</html>
