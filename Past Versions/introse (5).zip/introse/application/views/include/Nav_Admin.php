  <!-- Navigation -->
      <nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="<?php echo base_url("/Admin_Cont");?>">Council of Student Organizations - APS</a>
            </div>
            <!-- /.navbar-header -->
            <ul class="nav navbar-top-links navbar-right">
                <li>Admin</li>
                <li class="dropdown">
                    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                        <i class="fa fa-user fa-fw"></i> <i class="fa fa-caret-down"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user">
                        <li><a href="" id="submitBtn" data-toggle="modal" data-target="#setting"/><i class="fa fa-gear fa-fw"></i>Settings</a></li>
                        </li>
                        <li class="divider"></li>
                        <li><a href="<?php echo base_url("/Login");?>"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                        </li>
                    </ul>
                </li>
            </ul>
            <!-- /.navbar-top-links -->
            <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li>
                            <a href="<?php echo base_url("/Admin_Cont");?>"><i class="fa fa-table fa-fw"></i> Calendar</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url("/DtsAdmin_Cont");?>"><i class="fa fa-table fa-fw"></i> DTS</a>
                        </li>
                        <li>
                            <a href="<?php echo base_url("/GosmAdmin_Cont");?>"><i class="fa fa-paperclip fa-fw"></i> GOSM</a>
                        </li>
                     
                    </ul>
                </div>
            </div>
        </nav>


    <div class="modal fade" id="setting" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
         <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                  <button type="button" class="close" data-dismiss="modal" aria-label="Close" id= "close"><span aria-hidden="true">&times;</span></button>
                  <h3 class="modal-title"> Settings </h3>
                
                    </div>
                    <div class="modal-body">
                          <div>
                                <label>School Year:</label>
                                <span ><?php echo $SchoolYear;?></span>
                                &nbsp; &nbsp;
                                <label>Term:</label>
                                <span ><?php echo $SchoolTerm;?></span>
                            </div>

                            <div>
                                <label>Duration:</label>
                                <span ><?php echo $Start;?></span>
                                <label>—</label>
                                <span ><?php echo $End;?></span>
                            </div>
                 

                        <div class="modal-footer">
                            <span id = "NewTerm">
                            <style>
                                #NewTerm{
                                     position:relative;
                                     float:left;
                                     padding-left:0px;
                                }
                            </style>
                            <input type ="submit" value="New Term" id="submit" class="btn btn-success" data-toggle="modal" data-target ="#new"></span>
                            <span id = "NewTerm">
                            <style>
                                #NewTerm{
                                     position:relative;
                                     float:left;
                                     padding-left:10px;
                                }
                            </style>
                            <input type ="submit" value="Update" id="submit" class="btn btn-success" data-toggle="modal" data-target ="#update"></span>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class= "container">
        <div class="modal fade" id="new" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close" id= "close"><span aria-hidden="true">&times;</span></button>
                          <h3 class="modal-title">New Term</h3>
                        </div>
                        <div class="modal-body form" style= "text-align :left">
                        <form id="newForm" class="jsform">
                                     <div>
                                         <label class="control-label">School Year</label> &nbsp;
                                          <span style="display: block"></span>
                                             <input name="year1" id="year1" class="form-control" type="text">
                                              <label>—</label>
                                             <input name="year2" id="year2" class="form-control" type="text">
                                             <span class="help-block"></span>

                                             <style>
                                                #year1, #year2{
                                                    display: inline;
                                                    width: 30%;
                                                }
                                             </style>
                                          
                                     </div>
                                     <div>
                                        <label class="control-label">Term</label>
                                            <select name="term" class="form-control" style= "width: 26%">
                                                <option value="">--Select Term--</option>
                                                <option value="1">1</option>
                                                <option value="2">2</option>
                                                <option value="3">3</option>
                                            </select>
                                            <span class="help-block"></span>
                                     </div>
                                     <div>
                                        <label class="control-label">Term Duration</label>
                                        <div class="input-group">
                                            <input class="form-control" id="datePicker1" name="datePicker1" placeholder="MM/DD/YYY" type="text">
                                                <span class="input-group-addon" name="dash" id="dash">-</span>
                                            <input class="form-control" id="datePicker2" name="
                                            datePicker2" placeholder="MM/DD/YYY" type="text">

                                        </div>
                                            <span class="help-block"></span>
                                     </div>
                        </div>
                        <div class="modal-footer">
                            
                            <input type ="submit" value="Confirm" id="submit" class="btn btn-success" data-toggle="modal">
                        </div>
                            </form>
                    </div><!-- /.modal-content -->
                </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->
            </div>

             <script>
        $(document).ready(function(){
            var date_input=$('input[name="datePicker1"]');
            var date = new Date();
            date.setDate(date.getDate()-1);
            var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy-mm-dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
                startDate: date,
            })
        })
    </script>
    <script>
        $(document).ready(function(){
            var date_input=$('input[name="datePicker2"]');
            var date = new Date();
            date.setDate($('#datePicker1').datepicker("getDate"));
            var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
            date_input.datepicker({
                format: 'yyyy-mm-dd',
                container: container,
                todayHighlight: true,
                autoclose: true,
                startDate: date,
            })
         })
    </script>

 