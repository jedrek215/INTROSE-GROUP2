<?php 
Class GosmOrg_Model extends CI_Model
{
    function __construct() {
        parent::__construct();
        $this->load->database();
    }
 
    
   function getGosm($orgname, $limit, $start)
   {
     $code = 'SELECT *
              from gosm, org, targetdate
              where OrgName = '.'"'.$orgname.'"'.' and OrgID = Gosm_OrgID 
              and gosmID = date_gosmID';

      if($limit != 0 ){
         $code =  $code . ' limit ' . $start . ', ' . $limit;
     }


      $query = $this->db->query($code);
      if($query->num_rows()>0){

        return $query->result();
      }else {
        return NULL;
      }

    }

   
}

?>